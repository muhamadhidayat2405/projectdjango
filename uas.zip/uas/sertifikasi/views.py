from django.shortcuts import render

from .models import Sertifikasi


def index(request):

    postingan = Sertifikasi.objects.all()

    context = {
        'TampungPostingan': postingan,

    }

    return render(request, 'sertifikasi/index.html', context)
