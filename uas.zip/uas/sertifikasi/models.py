from django.db import models



class Sertifikasi(models.Model):
    sertifikasi = models.CharField(max_length=255)
    materi = models.CharField(max_length=255)

    def __str__(self):
        return self.sertifikasi