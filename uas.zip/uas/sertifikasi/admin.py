from django.contrib import admin

from .models import Sertifikasi

admin.site.register(Sertifikasi)