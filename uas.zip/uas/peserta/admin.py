from django.contrib import admin

from .models import Peserta,Sertifikasi

admin.site.register(Peserta)
admin.site.register(Sertifikasi)