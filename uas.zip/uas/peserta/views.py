from django.shortcuts import render

from .models import Peserta


def index(request):

    postingan = Peserta.objects.all()

    context = {
        'TampungPostingan': postingan,

    }

    return render(request, 'peserta/index.html', context)
